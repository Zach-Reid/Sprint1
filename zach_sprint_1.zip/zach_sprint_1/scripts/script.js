//Collecting inputs from order.html
document.getElementById('orderForm').addEventListener('submit', function(event) {
    event.preventDefault();
//name
    const nameInput = document.getElementById('name').value;
    document.getElementById('displayName').innerText = 'Thank you for your purchase, ' + nameInput +'.';
//address
    const addressInput = document.getElementById('address').value;
    document.getElementById('displayAddress').innerText = 'Address: ' + addressInput;
//order total:
    const foodone = document.getElementById('food1').value;
    document.getElementById('first').innerText = 'Big Gary: ' + foodone;

    const foodtwo = document.getElementById('food2').value;
    document.getElementById('second').innerText = 'Fries: ' + foodtwo;

    const foodthree = document.getElementById('food3').value;
    document.getElementById('third').innerText = 'Chicken Strips: ' + foodthree + ' pieces';

    const foodfour = document.getElementById('food4').value;
    document.getElementById('fourth').innerText = 'Coleslaw: ' + foodfour;

    const foodfive = document.getElementById('food5').value;
    document.getElementById('fifth').innerText = 'Gravy: ' + foodfive;

    const foodsix = document.getElementById('food6').value;
    document.getElementById('sixth').innerText = 'Classic Chicken: ' + foodsix + ' pieces';

    const foodseven = document.getElementById('food7').value;
    document.getElementById('seventh').innerText = 'Pudding: ' + foodseven;

    const foodeight = document.getElementById('food8').value;
    document.getElementById('eighth').innerText = 'Drinks: ' + foodeight;

    const foodnine = document.getElementById('food9').value;
    document.getElementById('ninth').innerText = 'Biscuits: ' + foodnine;


});